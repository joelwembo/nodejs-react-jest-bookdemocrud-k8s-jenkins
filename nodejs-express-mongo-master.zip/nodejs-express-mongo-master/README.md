# nodejs-express-mongo
![image](https://github.com/joelwembo/nodejs-express-mongo/assets/19718580/12d513e8-0601-4112-a788-badb1a24abfd)

